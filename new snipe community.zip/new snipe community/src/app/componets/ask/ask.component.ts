
import { Component, OnInit,Inject  } from '@angular/core';
import { NgForm }    from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import { Router }  from '@angular/router';
import { UserService } from '../../services/user.service'
import 'rxjs/Rx';

@Component({
  selector: 'app-ask',
  templateUrl: './ask.component.html',
  styleUrls: ['./ask.component.css']
  
  })
export class AskComponent implements OnInit {

  form: FormGroup;
  successMessage:string = '';
  errorMessage:string = '';
  
 constructor(private fb: FormBuilder,private userService : UserService, private router: Router){}
  ngOnInit() {
     this.form = this.fb.group({    
    
     tag: ['',[Validators.required, Validators.maxLength(20)] ],
      question: ['',[Validators.required, Validators.maxLength(200)] ],
      });
    
  }
 
  
 
    
  ask() {
    this.successMessage = '';  
   this.errorMessage = '';
    //this.router.navigate(['./home']);
	this.userService.askUser(this.form.value)
  .subscribe(
      (data) => {console.log(data)
      this.successMessage = 'succes';  
    },
      (error) => console.log(error),  
      () => console.log('success')  
    
	);
	
  
  
console.log("data in component"+JSON.stringify(this.form.value));
     this.call();
	 }
 call() {
   this.userService.askUser(JSON.stringify(this.form.value));

  }
}

